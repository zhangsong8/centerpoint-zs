
```
globle_scene
     cameraHelper
     world: webgl-group
         + lidar
         + annotations: group
             + box
             + box
         + boxeditor.boxView.view: cameraContainer
             + camera
         + auxlidar
         + radar
    world
    world
```