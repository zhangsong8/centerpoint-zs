

exe = "../../code/lie/build/cluster"

