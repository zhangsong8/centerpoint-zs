1. the views on the left are 3 orthographical cameras installed in the scene according to the selected box. keys 5/6/7 to show/hide the installed camera frames.

2. we use rear-view, other than front-view, so that when we adjust the position of box, this view moves 
in the same direction as the top-down view, otherwise it would be very confusing (imagine the box in the 
first view moves right but in the second view moves left.)

2. the main view is a perspective camera by default.


