var settings= {
    ground_filter_height: 0.2,
    initial_z_position: -0.9,

}

export {settings}