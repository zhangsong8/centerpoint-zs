#!/usr/bin/env bash

cd /root/SUSTechPOINTS && python3 ./main.py
